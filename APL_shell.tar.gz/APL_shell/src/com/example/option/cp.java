
	package com.example.option;
	import java.io.*;

	import android.app.ActivityGroup;
//	import android.app.AlertDialog;
	import android.os.Bundle;
	import android.os.Environment;
	import android.util.Log;
	//import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
	//import android.view.View;
	import android.webkit.WebChromeClient;
	import android.webkit.WebSettings;
	import android.webkit.WebView;
	//import android.widget.Button;

import com.example.option.R;
import android.webkit.JsResult;
	public class cp extends ActivityGroup {
	    /** Called when the activity is first created. */
		 @Override
		    
		    public boolean onCreateOptionsMenu(Menu menu) {
		        MenuInflater inflater = getMenuInflater();
		        inflater.inflate(R.menu.menu1, menu);
		        return true;
		 }
	   
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.main1);
	        //Button buttonSave = (Button)findViewById(R.id.savecode);
	        
	        
	        
	        WebView engine = (WebView) findViewById(R.id.webView1); 
	        
	        WebSettings webSettings = engine.getSettings();
	        webSettings.setJavaScriptEnabled(true);
	        //engine.loadUrl("file:///sdcard/html/c/index.html"); 
	       // engine.loadUrl("localhost/html/c/index.html"); 
	        //engine.loadUrl("http://10.101.201.172/html/c/index.html"); 
	        //engine.loadUrl("http://10.101.201.146/html/cpp/index.html"); 
	        engine.loadUrl("http://127.0.0.1/html/cpp/index.html"); 
	        engine.setWebChromeClient(new WebChromeClient()

	        {
	            @Override
	            public void onConsoleMessage(String message, int lineNumber,String sourceID) {
	                Log.d("MyApplication", message + " -- From line "+ lineNumber + " of " + sourceID);
	                super.onConsoleMessage(message, lineNumber, sourceID);
	            }

	        });
	        
WebView engine1 = (WebView) findViewById(R.id.webView2); 
	        
	        WebSettings webSettings1 = engine1.getSettings();
	        webSettings1.setJavaScriptEnabled(true);
	       // engine1.loadUrl("file:///sdcard/mydir/html/cpp/index.html"); 
	        //engine1.loadUrl("http://10.101.201.146:4200"); 
	        engine1.loadUrl("http://127.0.0.1:4200"); 
	        engine1.setWebChromeClient(new WebChromeClient()

	        {
	            @Override
	            public void onConsoleMessage(String message, int lineNumber,String sourceID) {
	                Log.d("MyApplication", message + " -- From line "+ lineNumber + " of " + sourceID);
	                super.onConsoleMessage(message, lineNumber, sourceID);
	            }

	        });
	
	        
	        
	       // buttonSave.setOnClickListener(buttonSaveOnClickListener);         
	    }
	    
	    public void test()
	    { 
	    	
	    	  // TODO Auto-generated method stub
  	    	 WebView engine = (WebView) findViewById(R.id.web_engine); 
  	    	 //engine.setWebViewClient(new MyWebViewClient());
  	    	 WebSettings webSettings = engine.getSettings();
  	         webSettings.setJavaScriptEnabled(true);
  	         engine.getSettings().setJavaScriptEnabled(true);
  	         engine.setWebChromeClient(new MyWebChromeClientcpp());
  	         
  	         //engine.addJavascriptInterface(android_interface, "api");
  	 
  	         //engine.loadUrl("javascript:savecode()");
  	         engine.loadUrl("javascript:alert(savecode())");
	 
  	         
	    }
	    
	    public void save_android(String filename){
			InputStream inStream = null;
	  	  	OutputStream outStream = null;
			 
		      	try{
		  	   
		/*you will have to ask sir and put the proper path of tmp folder in the line below*/
				String sourcePath = "/data/local/linux/var/www/html/cpp/tmp";
		      	    	File afile2 =new File(sourcePath);
		      		/*in below line it should be "c" for c file "py" for python etc */
		      	    	FilenameFilter only = new OnlyExt("cpp");
		      	    	String s[] =afile2.list(only);
		      	    
		      	    	File afile=new File(sourcePath + "/" +  s[0]);
		      	     	File bfile =new File(Environment.getExternalStorageDirectory() + "/" + filename + ".cpp");
		   
		      	    	inStream = new FileInputStream(afile);
		      	    	outStream = new FileOutputStream(bfile);
		   
		      	    	byte[] buffer = new byte[1024];
		   
		      	    	int length;
		      	    	//copy the file content in bytes 
		      	    	while ((length = inStream.read(buffer)) > 0){
		   
		      	    		outStream.write(buffer, 0, length);
		   
		      	    	}
		   
		      	    	inStream.close();
		      	    	outStream.close();
		   
		      	    	//delete the original file
		      	    	afile.delete();
		      	    	
		      	    
		      	}catch(IOException e){
		      	    e.printStackTrace();
		      	}
		      
		      
		}
	    
	    
	    
	    @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	        // Handle item selection
	        switch (item.getItemId()) {
	            case R.id.savecode1:
	            	 test();
	           	    
	                return true;
	            
	            default:
	                return super.onOptionsItemSelected(item);
	        }
	    }
	}

	final class MyWebChromeClientcpp extends WebChromeClient

    {
		
		cp jb = new cp();
		@Override
     public void onConsoleMessage(String message, int lineNumber,String sourceID) {
         Log.d("MyApplication", message + " -- From line "+ lineNumber + " of " + sourceID);
         super.onConsoleMessage(message, lineNumber, sourceID);
     
     }
     @Override
     public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
       Log.d("LogTag", message);
       System.out.println("AKK");
      	 jb.save_android(message);
       
       result.confirm();
       return true;
   }


    }


