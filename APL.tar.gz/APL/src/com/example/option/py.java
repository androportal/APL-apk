
	package com.example.option;
	import java.io.*;

	import android.app.ActivityGroup;
	import android.app.AlertDialog;
	import android.os.Bundle;
	import android.os.Environment;
	import android.util.Log;
	import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
	import android.view.View;
	import android.webkit.WebChromeClient;
	import android.webkit.WebSettings;
	import android.webkit.WebView;
	import android.widget.Button;

import com.example.option.R;

	public class py extends ActivityGroup {
	    /** Called when the activity is first created. */
		 @Override
		    
		    public boolean onCreateOptionsMenu(Menu menu) {
		        MenuInflater inflater = getMenuInflater();
		        inflater.inflate(R.menu.menu1, menu);
		        return true;
		 }
	   
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.main1);
	        //Button buttonSave = (Button)findViewById(R.id.savecode);
	        
	        
	        
	        WebView engine = (WebView) findViewById(R.id.web_engine); 
	        
	        WebSettings webSettings = engine.getSettings();
	        webSettings.setJavaScriptEnabled(true);
	        //engine.loadUrl("file:///sdcard/html/c/index.html"); 
	       // engine.loadUrl("localhost/html/c/index.html"); 
	        //engine.loadUrl("http://10.101.201.172/html/c/index.html"); 
	        //engine.loadUrl("http://10.101.201.192/html/c/index.html"); 
	        engine.loadUrl("http://127.0.0.1/html/python/index.html"); 
	        engine.setWebChromeClient(new WebChromeClient()

	        {
	            @Override
	            public void onConsoleMessage(String message, int lineNumber,String sourceID) {
	                Log.d("MyApplication", message + " -- From line "+ lineNumber + " of " + sourceID);
	                super.onConsoleMessage(message, lineNumber, sourceID);
	            }

	        });
	       // buttonSave.setOnClickListener(buttonSaveOnClickListener);         
	    }
	    
	    public void test()
	    {
	    	  // TODO Auto-generated method stub
  	    	 WebView engine = (WebView) findViewById(R.id.web_engine); 
  	    	 WebSettings webSettings = engine.getSettings();
  	         webSettings.setJavaScriptEnabled(true);
  	        // engine.addJavascriptInterface(new MyJSJavaBridge(), "api");

  	      engine.loadUrl("javascript:savecode()");
  	      InputStream inStream = null;
  	  	OutputStream outStream = null;
  	   
  	      	try{
  	      		int i;
  	      		for(i=0;i<100000; i++)
  	      		{
  	      			
  	      		}
  	   
  	/*you will have to ask sir and put the proper path of tmp folder in the line below*/
  			String sourcePath = "/data/local/ubuntu/var/www/html/python/tmp";
  	      	    	File afile2 =new File(sourcePath);
  	      		/*in below line it should be "c" for c file "py" for python etc */
  	      	    	FilenameFilter only = new OnlyExt("py");
  	      	    	String s[] =afile2.list(only);
  	      	    
  	      	    	File afile=new File(sourcePath + "/" +  s[0]);
  	      	     	File bfile =new File(Environment.getExternalStorageDirectory() + "/" + s[0]);
  	   
  	      	    	inStream = new FileInputStream(afile);
  	      	    	outStream = new FileOutputStream(bfile);
  	   
  	      	    	byte[] buffer = new byte[1024];
  	   
  	      	    	int length;
  	      	    	//copy the file content in bytes 
  	      	    	while ((length = inStream.read(buffer)) > 0){
  	   
  	      	    		outStream.write(buffer, 0, length);
  	   
  	      	    	}
  	   
  	      	    	inStream.close();
  	      	    	outStream.close();
  	   
  	      	    	//delete the original file
  	      	    	afile.delete();
  	      	    	
  	      	    
  	      	}catch(IOException e){
  	      	    e.printStackTrace();
  	      	}
  	      
  	      
  	      
  	      
  	      engine.setWebChromeClient(new WebChromeClient()

  	      {
  	          @Override
  	          public void onConsoleMessage(String message, int lineNumber,String sourceID) {
  	              Log.d("MyApplication", message + " -- From line "+ lineNumber + " of " + sourceID);
  	              super.onConsoleMessage(message, lineNumber, sourceID);
  	          }

  	      });
  	     
  	      
   	 
  	     

	    }
	    
	    
	    
	    @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	        // Handle item selection
	        switch (item.getItemId()) {
	            case R.id.savecode1:
	            	 test();
	           	    
	                return true;
	            
	            default:
	                return super.onOptionsItemSelected(item);
	        }
	    }
	}



